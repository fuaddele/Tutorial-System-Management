<!DOCTYPE html>
<html>
<head>
  <title>Tutorial Creation</title>
  <style>
    /* CSS styles for the form */
    .form-container {
      width: 400px;
      margin: 0 auto;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
    }

    .form-group input,
    .form-group select {
      width: 100%;
      padding: 5px;
    }

    .form-group button {
      padding: 10px 20px;
      background-color: #007bff;
      color: #fff;
      border: none;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Tutorial Creation</h2>
    <form id="tutorial-creation-form">
      <div class="form-group">
        <label for="tutorial-date">Tutorial Date</label>
        <input type="date" id="tutorial-date" name="tutorial_date" required>
      </div>
      <div class="form-group">
        <label for="tutorial-time">Tutorial Time</label>
        <input type="time" id="tutorial-time" name="tutorial_time" required>
      </div>
      <div class="form-group">
        <label for="students">Students</label>
        <select id="students" name="students[]" multiple required>
          <!-- Populate this select element with student options from the database -->
          <!-- Example: -->
          <option value="1">John Doe</option>
          <option value="2">Jane Smith</option>
          <option value="3">Alex Johnson</option>
        </select>
      </div>
      <div class="form-group">
        <label for="tutor">Tutor</label>
        <select id="tutor" name="tutor" required>
          <!-- Populate this select element with tutor options from the database -->
          <!-- Example: -->
          <option value="1">Mr. John Smith</option>
          <option value="2">Ms. Emily Johnson</option>
          <option value="3">Dr. Michael Brown</option>
        </select>
      </div>
      <div class="form-group">
        <label for="fee">Fee (€)</label>
        <input type="number" id="fee" name="fee" required>
      </div>
      <div class="form-group">
        <label for="tutorial-number">Tutorial Number</label>
        <input type="number" id="tutorial-number" name="tutorial_number" required>
      </div>
      <div class="form-group">
        <label for="tutorial-attendance">Tutorial Attendance</label>
        <select id="tutorial-attendance" name="tutorial_attendance" required>
          <option value="Attended">Attended</option>
          <option value="Cancelled">Cancelled</option>
          <option value="No Show">No Show</option>
        </select>
      </div>
      <div class="form-group">
        <label for="tutorial-subject">Tutorial Subject</label>
        <select id="tutorial-subject" name="tutorial_subject" required>
          <option value="English">English</option>
          <option value="Irish">Irish</option>
          <option value="Maths">Maths</option>
          <option value="Biology">Biology</option>
          <option value="Chemistry">Chemistry</option>
          <option value="Physics">Physics</option>
          <option value="Computer Science">Computer Science</option>
        </select>
      </div>
      <div class="form-group">
        <label for="tutorial-notes">Tutorial Notes</label>
        <textarea id="tutorial-notes" name="tutorial_notes" rows="4" required></textarea>
      </div>
      <div class="form-group">
        <button type="submit">Create Tutorial</button>
      </div>
    </form>
  </div>

  <script>
    // Handle form submission
    document.getElementById('tutorial-creation-form').addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent default form submission behavior

      // Get form data
      var formData = new FormData(this);

      // Convert form data to JSON object
      var tutorialData = {};
      for (var [key, value] of formData.entries()) {
        tutorialData[key] = value;
      }

      // Send the tutorial data to the server via AJAX or fetch API
      // Replace the URL with the appropriate endpoint of your REST API
      var url = '/api/tutorials'; // Example URL
      fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(tutorialData)
      })
      .then(response => response.json())
      .then(data => {
        // Handle the response from the server
        // You can display a success message or redirect to another page
        console.log(data);
        alert('Tutorial created successfully!');
      })
      .catch(error => {
        // Handle any errors that occur during the request
        console.error('Error:', error);
        alert('An error occurred while creating the tutorial.');
      });
    });
  </script>
</body>
</html>
