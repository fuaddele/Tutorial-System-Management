<!DOCTYPE html>
<html>
<head>
  <title>Edit Tutorial</title>
</head>
<body>
  <h2>Edit Tutorial</h2>
  <?php
  // Check if tutorial ID is provided in the URL
  if (isset($_GET['id'])) {
    // Get the tutorial ID from the URL
    $tutorialId = $_GET['id'];

    
    $tutorial = [
      
    ];

    // Display the tutorial form with pre-filled data
    ?>
    <form method="post" action="update_tutorial.php">
      <input type="hidden" name="id" value="<?php echo $tutorial['id']; ?>">
      <label>Date:</label>
      <input type="date" name="date" value="<?php echo $tutorial['date']; ?>" required><br>
      <label>Time:</label>
      <input type="time" name="time" value="<?php echo $tutorial['time']; ?>" required><br>
      <label>Students:</label>
      <input type="text" name="students" value="<?php echo $tutorial['students']; ?>" required><br>
      <label>Tutor:</label>
      <input type="text" name="tutor" value="<?php echo $tutorial['tutor']; ?>" required><br>
      <label>Fee (€):</label>
      <input type="number" name="fee" value="<?php echo $tutorial['fee']; ?>" required><br>
      <label>Attendance:</label>
      <select name="attendance" required>
        <option value="Attended" <?php if ($tutorial['attendance'] === 'Attended') echo 'selected'; ?>>Attended</option>
        <option value="Cancelled" <?php if ($tutorial['attendance'] === 'Cancelled') echo 'selected'; ?>>Cancelled</option>
        <option value="No Show" <?php if ($tutorial['attendance'] === 'No Show') echo 'selected'; ?>>No Show</option>
      </select><br>
      <label>Subject:</label>
      <select name="subject" required>
        <option value="English" <?php if ($tutorial['subject'] === 'English') echo 'selected'; ?>>English</option>
        <option value="Maths" <?php if ($tutorial['subject'] === 'Maths') echo 'selected'; ?>>Maths</option>
        <option value="Science" <?php if ($tutorial['subject'] === 'Science') echo 'selected'; ?>>Science</option>
      </select><br>
      <label>Notes:</label>
      <textarea name="notes" rows="4" cols="50"><?php echo $tutorial['notes']; ?></textarea><br>
      <input type="submit" value="Update Tutorial">
    </form>
    <?php
  } else {
    echo '<p>No tutorial ID provided.</p>';
  }
  ?>
</body>
</html>
