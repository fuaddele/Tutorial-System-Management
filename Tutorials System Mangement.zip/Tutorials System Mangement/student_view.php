<!DOCTYPE html>
<html>
<head>
  <title>View Student Records</title>
  <style>
    /* CSS styles for the table */
    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #f2f2f2;
    }

    .edit-button, .delete-button {
      padding: 5px 10px;
      background-color: #007bff;
      color: #fff;
      border: none;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <h2>Student Records</h2>
  <table>
    <thead>
      <tr>
        <th>Student ID</th>
        <th>Name</th>
        <th>Phone Number</th>
        <th>Email Address</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
      // Replace with your code to fetch student records from the database
      // Example data
      $students = [
      ];

      foreach ($students as $student) {
        echo '<tr>';
        echo '<td>' . $student['id'] . '</td>';
        echo '<td>' . $student['name'] . '</td>';
        echo '<td>' . $student['phone'] . '</td>';
        echo '<td>' . $student['email'] . '</td>';
        echo '<td>';
        echo '<button class="edit-button" onclick="editStudent(' . $student['id'] . ')">Edit</button>';
        echo '<button class="delete-button" onclick="deleteStudent(' . $student['id'] . ')">Delete</button>';
        echo '</td>';
        echo '</tr>';
      }
      ?>
    </tbody>
  </table>

  <script>
    function editStudent(studentId) {
      // Replace with your code to handle edit action
      // Redirect to the edit student page with the studentId parameter
      window.location.href = 'edit_student.php?id=' + studentId;
    }

    function deleteStudent(studentId) {
      // Replace with your code to handle delete action
      // Show a confirmation dialog and then send an AJAX request to delete the student
      if (confirm('Are you sure you want to delete this student?')) {
        // Replace the URL with the appropriate endpoint of your REST API for deleting a student
        var url = '/api/students/' + studentId; // Example URL
        fetch(url, {
          method: 'DELETE'
        })
        .then(response => {
          if (response.ok) {
            // Handle successful deletion
            alert('Student deleted successfully!');
            window.location.reload(); // Refresh the page to reflect the changes
          } else {
            // Handle deletion failure
            throw new Error('Failed to delete student.');
          }
        })
        .catch(error => {
          // Handle any errors that occur during the request
          console.error('Error:', error);
          alert('An error occurred while deleting the student.');
        });
      }
    }
  </script>
</body>
</html>
