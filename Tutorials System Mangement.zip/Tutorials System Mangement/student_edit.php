<!DOCTYPE html>
<html>
<head>
  <title>Edit Student</title>
</head>
<body>
  <h2>Edit Student</h2>

  <?php
  // Check if the student ID is provided in the URL parameter
  if (isset($_GET['id'])) {
    $studentId = $_GET['id'];


    $student = [

    ];

    // Display the student record in an HTML form for editing
    ?>
    <form method="POST" action="update_student.php">
      <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
      <label for="name">Name:</label>
      <input type="text" name="name" value="<?php echo $student['name']; ?>" required><br>
      <label for="phone">Phone Number:</label>
      <input type="text" name="phone" value="<?php echo $student['phone']; ?>" required><br>
      <label for="email">Email Address:</label>
      <input type="email" name="email" value="<?php echo $student['email']; ?>" required><br>
      <button type="submit">Save Changes</button>
    </form>
    <?php
  } else {
    // If the student ID is not provided, display an error message
    echo 'Invalid student ID.';
  }
  ?>

</body>
</html>
