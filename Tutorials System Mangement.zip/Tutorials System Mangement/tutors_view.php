<!DOCTYPE html>
<html>
<head>
  <title>View Tutor Records</title>
  <style>
    /* CSS styles for the table */
    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #f2f2f2;
    }

    .edit-button, .delete-button {
      padding: 5px 10px;
      background-color: #007bff;
      color: #fff;
      border: none;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <h2>Tutor Records</h2>
  <table>
    <thead>
      <tr>
        <th>Tutor ID</th>
        <th>Name</th>
        <th>Phone Number</th>
        <th>Email Address</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
      // Replace with your code to fetch tutor records from the database
      // Example data
      $tutors = [
      ];

      foreach ($tutors as $tutor) {
        echo '<tr>';
        echo '<td>' . $tutor['id'] . '</td>';
        echo '<td>' . $tutor['name'] . '</td>';
        echo '<td>' . $tutor['phone'] . '</td>';
        echo '<td>' . $tutor['email'] . '</td>';
        echo '<td>';
        echo '<button class="edit-button" onclick="editTutor(' . $tutor['id'] . ')">Edit</button>';
        echo '<button class="delete-button" onclick="deleteTutor(' . $tutor['id'] . ')">Delete</button>';
        echo '</td>';
        echo '</tr>';
      }
      ?>
    </tbody>
  </table>

  <script>
    function editTutor(tutorId) {
      // Replace with your code to handle edit action
      // Redirect to the edit tutor page with the tutorId parameter
      window.location.href = 'edit_tutor.php?id=' + tutorId;
    }

    function deleteTutor(tutorId) {
      // Replace with your code to handle delete action
      // Show a confirmation dialog and then send an AJAX request to delete the tutor
      if (confirm('Are you sure you want to delete this tutor?')) {
        // Replace the URL with the appropriate endpoint of your REST API for deleting a tutor
        var url = '/api/tutors/' + tutorId; // Example URL
        fetch(url, {
          method: 'DELETE'
        })
        .then(response => {
          if (response.ok) {
            // Handle successful deletion
            alert('Tutor deleted successfully!');
            window.location.reload(); // Refresh the page to reflect the changes
          } else {
            // Handle deletion failure
            throw new Error('An error occurred while deleting the tutor.');
          }
        })
        .catch(error => {
          // Handle any errors that occur during the request
          console.error('Error:', error);
          alert('An error occurred while deleting the tutor.');
        });
      }
    }
  </script>
</body>
</html>
