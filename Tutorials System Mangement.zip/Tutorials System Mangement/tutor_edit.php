<!DOCTYPE html>
<html>
<head>
  <title>Edit Tutor</title>
</head>
<body>
  <h2>Edit Tutor</h2>

  <?php
  // Check if the tutor ID is provided in the URL parameter
  if (isset($_GET['id'])) {
    $tutorId = $_GET['id'];

 
    $tutor = [
    ];

    // Display the tutor record in an HTML form for editing
    ?>
    <form method="POST" action="update_tutor.php">
      <input type="hidden" name="tutor_id" value="<?php echo $tutor['id']; ?>">
      <label for="name">Name:</label>
      <input type="text" name="name" value="<?php echo $tutor['name']; ?>" required><br>
      <label for="phone">Phone Number:</label>
      <input type="text" name="phone" value="<?php echo $tutor['phone']; ?>" required><br>
      <label for="email">Email Address:</label>
      <input type="email" name="email" value="<?php echo $tutor['email']; ?>" required><br>
      <button type="submit">Save Changes</button>
    </form>
    <?php
  } else {
    // If the tutor ID is not provided, display an error message
    echo 'Invalid tutor ID.';
  }
  ?>

</body>
</html>
