API Documentation

The Tutorial Management System provides the following RESTful API endpoints for managing students, tutors, and tutorials.

Students

GET /api/students: Retrieve a list of all students.
GET /api/students/{id}: Retrieve details of a specific student by ID.
POST /api/students: Create a new student.
PUT /api/students/{id}: Update details of a specific student by ID.
DELETE /api/students/{id}: Delete a specific student by ID.
Tutors

GET /api/tutors: Retrieve a list of all tutors.
GET /api/tutors/{id}: Retrieve details of a specific tutor by ID.
POST /api/tutors: Create a new tutor.
PUT /api/tutors/{id}: Update details of a specific tutor by ID.
DELETE /api/tutors/{id}: Delete a specific tutor by ID.
Tutorials

GET /api/tutorials: Retrieve a list of all tutorials.
GET /api/tutorials/{id}: Retrieve details of a specific tutorial by ID.
POST /api/tutorials: Create a new tutorial.
PUT /api/tutorials/{id}: Update details of a specific tutorial by ID.
DELETE /api/tutorials/{id}: Delete a specific tutorial by ID.
Request Headers

All requests to the API endpoints should include the following headers:

Content-Type: application/json: Specifies the content type of the request payload.
Request Parameters

{id}: The unique identifier of the student, tutor, or tutorial.
Request Body

The request body for creating or updating a student, tutor, or tutorial should be a JSON object with the following properties:

For students:

title: The title of the student.
firstName: The first name of the student.
surname: The surname of the student.
phoneNumber: The phone number of the student.
email: The email address of the student.
addressLine1: The first line of the student's address.
addressLine2: The second line of the student's address (optional).
town: The town of the student's address.
county: The county/city of the student's address.
eircode: The EIRCODE of the student's address.
dateOfBirth: The date of birth of the student (optional).
guardianName: The name of the student's parent/guardian (optional).
virtualAttendance: Indicates whether the student has permission to attend tutorials virtually (Y/N) (optional).
gender: The gender of the student (optional).
subject: The subject of the student (optional).
For tutors:

title: The title of the tutor.
firstName: The first name of the tutor.
surname: The surname of the tutor.
phoneNumber: The phone number of the tutor.
email: The email address of the tutor.
addressLine1: The first line of the tutor's address.
addressLine2: The second line of the tutor's address (optional).
town: The town of the tutor's address.
county: The county/city of the tutor's address.
eircode: The EIRCODE of the tutor's address.