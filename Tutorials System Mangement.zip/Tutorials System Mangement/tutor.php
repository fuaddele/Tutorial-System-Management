<!DOCTYPE html>
<html>
<head>
  <title>Tutor Registration</title>
  <style>
    /* CSS styles for the form */
    .form-container {
      width: 400px;
      margin: 0 auto;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
    }

    .form-group input {
      width: 100%;
      padding: 5px;
    }

    .form-group button {
      padding: 10px 20px;
      background-color: #007bff;
      color: #fff;
      border: none;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Tutor Registration</h2>
    <form id="tutor-registration-form">
      <div class="form-group">
        <label for="title">Title</label>
        <select id="title" name="title">
          <option value="Mx">Mx</option>
          <option value="Ms">Ms</option>
          <option value="Mr">Mr</option>
          <option value="Mrs">Mrs</option>
          <option value="Miss">Miss</option>
          <option value="Other">Other</option>
        </select>
      </div>
      <div class="form-group">
        <label for="first-name">First Name</label>
        <input type="text" id="first-name" name="first_name" required>
      </div>
      <div class="form-group">
        <label for="surname">Surname</label>
        <input type="text" id="surname" name="surname" required>
      </div>
      <div class="form-group">
        <label for="phone-number">Phone Number</label>
        <input type="text" id="phone-number" name="phone_number" required>
      </div>
      <div class="form-group">
        <label for="email-address">Email Address</label>
        <input type="email" id="email-address" name="email_address" required>
      </div>
      <div class="form-group">
        <label for="address-line1">Address Line 1</label>
        <input type="text" id="address-line1" name="address_line1" required>
      </div>
      <div class="form-group">
        <label for="address-line2">Address Line 2</label>
        <input type="text" id="address-line2" name="address_line2">
      </div>
      <div class="form-group">
        <label for="town">Town</label>
        <input type="text" id="town" name="town" required>
      </div>
      <div class="form-group">
        <label for="county">County/City</label>
        <input type="text" id="county" name="county" required>
      </div>
      <div class="form-group">
        <label for="eircode">EIRCODE</label>
        <input type="text" id="eircode" name="eircode" required>
      </div>
      <button type="submit">Register</button>
    </form>
  </div>

  <script>
    // JavaScript code to handle form submission
    document.getElementById('tutor-registration-form').addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent form submission

      // Get form data
      var formData = new FormData(this);

      // Convert form data to JSON object
      var tutorData = {};
      for (var [key, value] of formData.entries()) {
        tutorData[key] = value;
      }

      // Send the tutor data to the server via AJAX or fetch API
      // Replace the URL with the appropriate endpoint of your REST API
      var url = '/api/tutors'; // Example URL
      fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(tutorData)
      })
      .then(response => response.json())
      .then(data => {
        // Handle the response from the server
        // You can display a success message or redirect to another page
        console.log(data);
        alert('Tutor registered successfully!');
      })
      .catch(error => {
        // Handle any errors that occur during the request
        console.error('Error:', error);
        alert('An error occurred while registering the tutor.');
      });
    });
  </script>
</body>
</html>