<!DOCTYPE html>
<html>
<head>
  <title>View Tutorial Records</title>
  <style>
    /* CSS styles for the table */
    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
  <h2>Tutorial Records</h2>
  <table>
    <thead>
      <tr>
        <th>Tutorial ID</th>
        <th>Date</th>
        <th>Time</th>
        <th>Students</th>
        <th>Tutor</th>
        <th>Fee</th>
        <th>Attendance</th>
        <th>Subject</th>
        <th>Notes</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
     
      $tutorials = [
      ];

      foreach ($tutorials as $tutorial) {
        echo '<tr>';
        echo '<td>' . $tutorial['id'] . '</td>';
        echo '<td>' . $tutorial['date'] . '</td>';
        echo '<td>' . $tutorial['time'] . '</td>';
        echo '<td>' . $tutorial['students'] . '</td>';
        echo '<td>' . $tutorial['tutor'] . '</td>';
        echo '<td>' . $tutorial['fee'] . '</td>';
        echo '<td>' . $tutorial['attendance'] . '</td>';
        echo '<td>' . $tutorial['subject'] . '</td>';
        echo '<td>' . $tutorial['notes'] . '</td>';
        echo '<td>';
        echo '<a href="edit_tutorial.php?id=' . $tutorial['id'] . '">Edit</a>';
        echo ' | ';
        echo '<a href="delete_tutorial.php?id=' . $tutorial['id'] . '">Delete</a>';
        echo '</td>';
        echo '</tr>';
      }
      ?>
    </tbody>
  </table>
</body>
</html>
