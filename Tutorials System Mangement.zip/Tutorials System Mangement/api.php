<?php
// Database Connection
$servername = "webcourse.cs.nuim.ie";
$username = "u220351";
$password = "oolahzoo5te4Kaej";
$dbname = "cs230_u220351";

// Create Connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set response content type to JSON
header('Content-Type: application/json');

// Tutor Registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SERVER['REQUEST_URI'] === '/api/tutors') {
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate and sanitize input data
    // ...

    // Insert the tutor record into the database
    $sql = "INSERT INTO tutors (title, first_name, last_name, phone_number, email, address) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $data['title'], $data['first_name'], $data['last_name'], $data['phone_number'], $data['email'], $data['address']);

    if ($stmt->execute()) {
        $response = [
            'success' => true,
            'message' => 'Tutor registration successful',
        ];
        echo json_encode($response);
    } else {
        $response = [
            'success' => false,
            'message' => 'Tutor registration failed',
        ];
        echo json_encode($response);
    }

    $stmt->close();
}

// Tutorial Creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SERVER['REQUEST_URI'] === '/api/tutorials') {
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate and sanitize input data
    // ...

    // Insert the tutorial record into the database
    $sql = "INSERT INTO tutorials (tutorial_date, tutorial_time, tutor_id, student_ids, fee, tutorial_number, tutorial_attendance, tutorial_subject, tutorial_notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssss", $data['tutorial_date'], $data['tutorial_time'], $data['tutor_id'], $data['student_ids'], $data['fee'], $data['tutorial_number'], $data['tutorial_attendance'], $data['tutorial_subject'], $data['tutorial_notes']);

    if ($stmt->execute()) {
        $response = [
            'success' => true,
            'message' => 'Tutorial creation successful',
        ];
        echo json_encode($response);
    } else {
        $response = [
            'success' => false,
            'message' => 'Tutorial creation failed',
        ];
        echo json_encode($response);
    }

    $stmt->close();
}

// View Student Records
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $_SERVER['REQUEST_URI'] === '/api/students') {
    $sql = "SELECT * FROM students";
    $result = $conn->query($sql);

    $students = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $students[] = $row;
        }
    }

    echo json_encode($students);
}

// Edit Student Record
if ($_SERVER['REQUEST_METHOD'] === 'PUT' && preg_match('/^\/api\/students\/(\d+)$/', $_SERVER['REQUEST_URI'], $matches)) {
    $studentId = $matches[1];
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate and sanitize input data
    // ...

    // Update the student record in the database
    $sql = "UPDATE students SET first_name = ?, last_name = ?, phone_number = ?, email = ?, address = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $data['first_name'], $data['last_name'], $data['phone_number'], $data['email'], $data['address'], $studentId);

    if ($stmt->execute()) {
        $response = [
            'success' => true,
            'message' => 'Student record updated successfully',
        ];
        echo json_encode($response);
    } else {
        $response = [
            'success' => false,
            'message' => 'Failed to update student record',
        ];
        echo json_encode($response);
    }

    $stmt->close();
}

// Delete Student Record
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && preg_match('/^\/api\/students\/(\d+)$/', $_SERVER['REQUEST_URI'], $matches)) {
    $studentId = $matches[1];

    // Delete the student record from the database
    $sql = "DELETE FROM students WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $studentId);

    if ($stmt->execute()) {
        $response = [
            'success' => true,
            'message' => 'Student record deleted successfully',
        ];
        echo json_encode($response);
    } else {
        $response = [
            'success' => false,
            'message' => 'Failed to delete student record',
        ];
        echo json_encode($response);
    }

    $stmt->close();
}

// View Tutor Records
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $_SERVER['REQUEST_URI'] === '/api/tutors') {
    $sql = "SELECT * FROM tutors";
    $result = $conn->query($sql);

    $tutors = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $tutors[] = $row;
        }
    }

    echo json_encode($tutors);
}

// Edit Tutor Record
if ($_SERVER['REQUEST_METHOD'] === 'PUT' && preg_match('/^\/api\/tutors\/(\d+)$/', $_SERVER['REQUEST_URI'], $matches)) {
    $tutorId = $matches[1];
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate and sanitize input data
    // ...

    // Update the tutor record in the database
    $sql = "UPDATE tutors SET first_name = ?, last_name = ?, phone_number = ?, email = ?, address = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $data['first_name'], $data['last_name'], $data['phone_number'], $data['email'], $data['address'], $tutorId);

    if ($stmt->execute()) {
        $response = [
            'success' => true,
            'message' => 'Tutor record updated successfully',
        ];
        echo json_encode($response);
    } else {
        $response = [
            'success' => false,
            'message' => 'Failed to update tutor record',
        ];
        echo json_encode($response);
    }

    $stmt->close();
}

// Delete Tutor Record
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && preg_match('/^\/api\/tutors\/(\d+)$/', $_SERVER['REQUEST_URI'], $matches)) {
    $tutorId = $matches[1];

    // Delete the tutor record from the database
    $sql = "DELETE FROM tutors WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $tutorId);

    if ($stmt->execute()) {
        $response = [
            'success' => true,
            'message' => 'Tutor record deleted successfully',
        ];
        echo json_encode($response);
    } else {
        $response = [
            'success' => false,
            'message' => 'Failed to delete tutor record',
        ];
        echo json_encode($response);
    }

    $stmt->close();
}

// View Tutorial Records
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $_SERVER['REQUEST_URI'] === '/api/tutorials') {
    $sql = "SELECT * FROM tutorials";
    $result = $conn->query($sql);

    $tutorials = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $tutorials[] = $row;
        }
    }

    echo json_encode($tutorials);
}

// Edit Tutorial Record
if ($_SERVER['REQUEST_METHOD'] === 'PUT' && preg_match('/^\/api\/tutorials\/(\d+)$/', $_SERVER['REQUEST_URI'], $matches)) {
    $tutorialId = $matches[1];
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate and sanitize input data
    // ...

    // Update the tutorial record in the database
    $sql = "UPDATE tutorials SET tutorial_date = ?, tutorial_time = ?, tutor_id = ?, student_ids = ?, fee = ?, tutorial_number = ?, tutorial_attendance = ?, tutorial_subject = ?, tutorial_notes = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssi", $data['tutorial_date'], $data['tutorial_time'], $data['tutor_id'], $data['student_ids'], $data['fee'], $data['tutorial_number'], $data['tutorial_attendance'], $data['tutorial_subject'], $data['tutorial_notes'], $tutorialId);

    if ($stmt->execute()) {
        $response = [
            'success' => true,
            'message' => 'Tutorial record updated successfully',
        ];
        echo json_encode($response);
    } else {
        $response = [
            'success' => false,
            'message' => 'Failed to update tutorial record',
        ];
        echo json_encode($response);
    }

    $stmt->close();
}

// Delete Tutorial Record
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && preg_match('/^\/api\/tutorials\/(\d+)$/', $_SERVER['REQUEST_URI'], $matches)) {
    $tutorialId = $matches[1];

    // Delete the tutorial record from the database
    $sql = "DELETE FROM tutorials WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $tutorialId);

    if ($stmt->execute()) {
        $response = [
            'success' => true,
            'message' => 'Tutorial record deleted successfully',
        ];
        echo json_encode($response);
    } else {
        $response = [
            'success' => false,
            'message' => 'Failed to delete tutorial record',
        ];
        echo json_encode($response);
    }

    $stmt->close();
}

// Close database connection
$conn->close();
