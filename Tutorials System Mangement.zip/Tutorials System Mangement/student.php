<!DOCTYPE html>
<html>
<head>
  <title>Student Registration</title>
  <style>
    /* CSS styles for the form */
    .form-container {
      width: 400px;
      margin: 0 auto;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
    }

    .form-group input {
      width: 100%;
      padding: 5px;
    }

    .form-group button {
      padding: 10px 20px;
      background-color: #007bff;
      color: #fff;
      border: none;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Student Registration</h2>
    <form id="student-registration-form">
      <div class="form-group">
        <label for="title">Title</label>
        <select id="title" name="title">
          <option value="Mx">Mx</option>
          <option value="Ms">Ms</option>
          <option value="Mr">Mr</option>
          <option value="Mrs">Mrs</option>
          <option value="Miss">Miss</option>
          <option value="Other">Other</option>
        </select>
      </div>
      <div class="form-group">
        <label for="first-name">First Name</label>
        <input type="text" id="first-name" name="first_name" required>
      </div>
      <div class="form-group">
        <label for="surname">Surname</label>
        <input type="text" id="surname" name="surname" required>
      </div>
      <div class="form-group">
        <label for="phone-number">Phone Number</label>
        <input type="text" id="phone-number" name="phone_number" required>
      </div>
      <div class="form-group">
        <label for="email-address">Email Address</label>
        <input type="email" id="email-address" name="email_address" required>
      </div>
      <div class="form-group">
        <label for="address-line1">Address Line 1</label>
        <input type="text" id="address-line1" name="address_line1" required>
      </div>
      <div class="form-group">
        <label for="address-line2">Address Line 2</label>
        <input type="text" id="address-line2" name="address_line2">
      </div>
      <div class="form-group">
        <label for="town">Town</label>
        <input type="text" id="town" name="town" required>
      </div>
      <div class="form-group">
        <label for="county">County/City</label>
        <input type="text" id="county" name="county" required>
      </div>
      <div class="form-group">
        <label for="eircode">EIRCODE</label>
        <input type="text" id="eircode" name="eircode" required>
      </div>
      <div class="form-group">
        <label for="date-of-birth">Date of Birth</label>
        <input type="date" id="date-of-birth" name="date_of_birth" required>
      </div>
      <div class="form-group">
        <label for="parent-guardian-name">Parent/Guardian Name</label>
        <input type="text" id="parent-guardian-name" name="parent_guardian_name">
      </div>
      <div class="form-group">
        <label for="permission-virtual">Permission to attend virtually</label>
        <select id="permission-virtual" name="permission_to_attend_virtually">
          <option value="Y">Yes</option>
          <option value="N">No</option>
        </select>
      </div>
      <div class="form-group">
        <label for="gender">Gender</label>
        <input type="text" id="gender" name="gender">
      </div>
      <div class="form-group">
        <label for="subject">Subject</label>
        <input type="text" id="subject" name="subject">
      </div>
      <button type="submit">Register</button>
    </form>
  </div>

  <script>
    // JavaScript code to handle form submission
    document.getElementById('student-registration-form').addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent form submission

      // Get form data
      var formData = new FormData(this);

      // Make AJAX request to the REST API endpoint
      var xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/students'); // Adjust the API endpoint URL
      xhr.setRequestHeader('Content-Type', 'application/json');

      // Convert form data to JSON
      var jsonObject = {};
      for (var [key, value] of formData.entries()) {
        jsonObject[key] = value;
      }
      var jsonData = JSON.stringify(jsonObject);

      // Send the request
      xhr.send(jsonData);

      // Handle the response
      xhr.onload = function() {
        if (xhr.status === 200) {
          alert('Student registered successfully!');
          // Reset the form
          document.getElementById('student-registration-form').reset();
        } else {
          alert('An error occurred while registering the student.');
        }
      };
    });
  </script>
</body>
</html>
